using UnityEngine;
using UnityEngine.UI;

public class ButtonSoundAndQuit : MonoBehaviour
{
    public Button yesButton;  // Reference to the "Yes" button
    public AudioSource audioSource;  // Reference to the AudioSource component for button click sound
    public AudioClip buttonClickSound;  // Reference to the button click sound

    void Start()
    {
        // Attach listener to the "Yes" button click event
        if (yesButton != null)
        {
            yesButton.onClick.AddListener(OnYesButtonClicked);
        }
    }

    // Method to play sound and quit the game
    void OnYesButtonClicked()
    {
        if (audioSource != null && buttonClickSound != null)
        {
            audioSource.PlayOneShot(buttonClickSound);  // Play the button click sound
            Invoke("QuitGame", buttonClickSound.length);  // Delay for sound to play before quitting
        }
        else
        {
            Debug.LogWarning("AudioSource or ButtonClickSound is not assigned. Quitting immediately.");
            QuitGame();  // Quit immediately if no sound is available
        }
    }

    // Method to quit the game
    void QuitGame()
    {
        #if UNITY_EDITOR
        // If running in Unity Editor, stop play mode (for testing)
        UnityEditor.EditorApplication.isPlaying = false;
        #else
        // If in a built version, quit the application
        Application.Quit();
        #endif
    }

    void OnDestroy()
    {
        // Detach listener to avoid memory leaks
        if (yesButton != null)
        {
            yesButton.onClick.RemoveListener(OnYesButtonClicked);
        }
    }
}
